(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const canvas = $('game');
  const ctx = canvas.getContext('2d', {alpha:true});
  const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
  function returnToGames(){window.location.href='index.html?skipIntro=1'}
  $('backGames').addEventListener('click',returnToGames);
  try{if(tg?.BackButton){tg.BackButton.show();tg.BackButton.onClick(returnToGames)}}catch(_){/* not supported */}

  try {
    if (tg) {
      tg.ready(); tg.expand();
      if (tg.setHeaderColor) tg.setHeaderColor('#101629');
      if (tg.setBackgroundColor) tg.setBackgroundColor('#101629');
      if (tg.disableVerticalSwipes) tg.disableVerticalSwipes();
    }
  } catch (err) { console.debug('Telegram display settings unavailable', err); }

  const el = {
    overlay:$('overlay'), panelStart:$('panelStart'),panelPause:$('panelPause'),panelEnd:$('panelEnd'),
    startBtn:$('startBtn'), pauseBtn:$('pauseBtn'), resumeBtn:$('resumeBtn'), retryBtn:$('retryBtn'),
    menuBtn:$('menuBtn'), restartPauseBtn:$('restartPauseBtn'),
    hud:$('hud'),hint:$('gameHint'),toast:$('toast'), score:$('score'),time:$('time'),
    hearts:$('hearts'),routeName:$('routeName'),routeCount:$('routeCount'),progress:$('progress'),
    endTitle:$('endTitle'),endIcon:$('endIcon'),endMessage:$('endMessage'),endScore:$('endScore'),
    endDelivery:$('endDelivery'),bestStart:$('bestStart'),backdrop:$('backdrop')
  };
  const routes = [
    {name:'Гриффиндор',color:'#ed6779',icon:'♜'},
    {name:'Слизерин',color:'#4ee6a5',icon:'✧'},
    {name:'Когтевран',color:'#70adff',icon:'✦'},
    {name:'Пуффендуй',color:'#ffd96d',icon:'◆'},
    {name:'Праздничный зал',color:'#ffcb86',icon:'★'}
  ];
  const MAX_TIME = 75, GOAL = 5;
  let W=390,H=780,dpr=1,lastTime=0,backgroundIndex=0,worldOffset=0;
  let state='menu',elapsed=0,score=0,health=3,delivered=0,hasGift=false,invuln=0;
  let owl={x:105,y:480,targetY:480};
  let entities=[],effects=[],snow=[],fireflies=[];
  let objectiveAt=1.2,obstacleAt=4,bonusAt=2.8,toastTimer=null,shake=0;
  let best=0, audioCtx=null;
  const owlImg = new Image();owlImg.src='assets/owl.png';
  function storageRead(key, fallback='0') { try {return localStorage.getItem(key)||fallback;}catch(_){return fallback;} }
  function storageWrite(key,val) {try {localStorage.setItem(key,val);}catch(_){/* private browsing */} }
  best = Math.max(0,Number(storageRead('owlmail_best','0'))||0);
  el.bestStart.textContent=best.toLocaleString('ru-RU');
  if(tg && tg.CloudStorage && tg.CloudStorage.getItem){
    try {tg.CloudStorage.getItem('owlmail_best',(err,value)=>{if(!err){const cloud=Number(value)||0; if(cloud>best){best=cloud;el.bestStart.textContent=best.toLocaleString('ru-RU');}}});}catch(_){/* not supported */}
  }

  function rnd(a,b){return a+Math.random()*(b-a);}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function haptic(type='light') {try{tg?.HapticFeedback?.impactOccurred(type);}catch(_){/* not supported */}}
  function notification(type='success'){try{tg?.HapticFeedback?.notificationOccurred(type);}catch(_){/* not supported */}}
  function playTone(freq=740,dur=.10,type='sine') {
    try {
      const Audio=window.AudioContext||window.webkitAudioContext;
      if(!Audio)return;
      if(!audioCtx)audioCtx=new Audio();
      if(audioCtx.state==='suspended')audioCtx.resume();
      const o=audioCtx.createOscillator(),g=audioCtx.createGain();
      o.type=type;o.frequency.value=freq;
      g.gain.setValueAtTime(.0001,audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(.038,audioCtx.currentTime+.018);
      g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+dur);
      o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+dur+.02);
    }catch(_){/* muted */}
  }
  function chime(){playTone(630,.15);setTimeout(()=>{if(state==='playing')playTone(945,.2);},115);}
  function toast(txt){
    el.toast.textContent=txt;el.toast.classList.add('show');
    if(toastTimer)clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>el.toast.classList.remove('show'),1200);
  }

  function resize(){
    const rect=canvas.getBoundingClientRect(); W=Math.max(1,rect.width);H=Math.max(1,rect.height);
    dpr=Math.min(window.devicePixelRatio||1,2);
    canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    owl.x=W*.255;owl.y=clamp(owl.y,H*.255,H*.83);owl.targetY=clamp(owl.targetY,H*.255,H*.83);
    if(!snow.length) initParticles();
  }
  function initParticles(){
    snow=Array.from({length:Math.min(75,Math.round(W*H/8000))},()=>({x:rnd(0,W),y:rnd(0,H),r:rnd(.8,2.7),s:rnd(12,53),drift:rnd(-15,12),a:rnd(.26,.86)}));
    fireflies=Array.from({length:13},()=>({x:rnd(0,W),y:rnd(H*.21,H*.9),phase:rnd(0,7),r:rnd(.7,2)}));
  }
  function applyBackground(i){
    backgroundIndex=i;
    el.backdrop.style.backgroundImage=`url('assets/bg_${i}.jpg')`;
    document.querySelectorAll('.theme-choice').forEach(b=>b.classList.toggle('selected',Number(b.dataset.bg)===i));
    storageWrite('owlmail_bg',String(i));
  }
  document.querySelectorAll('.theme-choice').forEach(b=>b.addEventListener('click',()=>{applyBackground(Number(b.dataset.bg));haptic();}));
  applyBackground(clamp(Number(storageRead('owlmail_bg','0'))||0,0,4));
  function showPanel(which){
    state=which==='start'?'menu':which==='pause'?'paused':'finished';
    el.overlay.classList.remove('hidden');
    for(const id of ['panelStart','panelPause','panelEnd'])el[id].classList.toggle('hidden',id!=='panel'+which.charAt(0).toUpperCase()+which.slice(1));
    el.hint.classList.add('hidden');
    el.hud.classList.toggle('hidden',which==='start');
    if(which==='start')el.bestStart.textContent=best.toLocaleString('ru-RU');
  }
  function updateHud(){
    el.score.textContent=score.toLocaleString('ru-RU');
    el.time.textContent=String(Math.ceil(Math.max(0,MAX_TIME-elapsed)));
    el.hearts.textContent=Array.from({length:3},(_,i)=>i<health?'♥':'♡').join(' ');
    const route=routes[Math.min(delivered,4)];
    el.routeName.textContent=route.name;
    el.routeName.style.color=route.color;
    el.routeCount.textContent=`${delivered} / ${GOAL}${hasGift?' · 🎁':''}`;
    [...el.progress.children].forEach((c,i)=>c.classList.toggle('done',i<delivered));
  }
  function newGame(){
    state='playing'; elapsed=0;score=0;health=3;delivered=0;hasGift=false; invuln=0;shake=0;
    owl={x:W*.255,y:H*.53,targetY:H*.53};
    entities=[];effects=[];objectiveAt=1.1;obstacleAt=5;bonusAt=3.2;
    el.overlay.classList.add('hidden');el.hud.classList.remove('hidden');el.hint.classList.remove('hidden');
    updateHud(); haptic('medium');playTone(550,.12);
    setTimeout(()=>{if(state==='playing')el.hint.classList.add('hidden');},5200);
  }
  function pause(){if(state!=='playing')return;showPanel('pause');haptic('light');}
  function resume(){if(state!=='paused')return;state='playing';el.overlay.classList.add('hidden');haptic('light');}
  function finish(win){
    if(state!=='playing')return;
    state='finished';el.overlay.classList.remove('hidden');
    el.panelStart.classList.add('hidden');el.panelPause.classList.add('hidden');el.panelEnd.classList.remove('hidden');
    el.hint.classList.add('hidden');
    el.endIcon.textContent=win?'🎄':'❄';
    el.endTitle.textContent=win?'Праздник спасён!':'Почта закрыта';
    el.endMessage.textContent=win?'Все подарки доставлены! Замок встречает Новый год.':'Подарки ещё ждут! Давай попробуем новый маршрут.';
    el.endScore.textContent=score.toLocaleString('ru-RU');el.endDelivery.textContent=`${delivered} / ${GOAL}`;
    if(score>best){best=score;storageWrite('owlmail_best',String(best));
      try{tg?.CloudStorage?.setItem('owlmail_best',String(best),()=>{});}catch(_){/* not supported */}
    }
    notification(win?'success':'warning');if(win){playTone(880,.4);burst(W*.50,H*.48,50,'#ffda83');}
  }
  el.startBtn.addEventListener('click',newGame);
  el.pauseBtn.addEventListener('click',pause);
  el.resumeBtn.addEventListener('click',resume);
  el.retryBtn.addEventListener('click',newGame);
  el.restartPauseBtn.addEventListener('click',newGame);
  el.menuBtn.addEventListener('click',()=>showPanel('start'));

  function setPointerY(e){const r=canvas.getBoundingClientRect();owl.targetY=clamp(e.clientY-r.top,H*.24,H*.84);}
  canvas.addEventListener('pointerdown',e=>{if(state!=='playing')return; e.preventDefault(); setPointerY(e);try{canvas.setPointerCapture(e.pointerId);}catch(_){}});
  canvas.addEventListener('pointermove',e=>{if(state!=='playing'||!(e.buttons || e.pointerType==='touch'))return;e.preventDefault();setPointerY(e);});
  window.addEventListener('keydown',e=>{
    if(e.key==='Escape'||e.key.toLowerCase()==='p'){state==='playing'?pause():state==='paused'?resume():null;return;}
    if(state==='playing'&&(e.key==='ArrowUp'||e.key==='ArrowDown'||e.key==='w'||e.key==='s')){
      owl.targetY=clamp(owl.targetY+(e.key==='ArrowUp'||e.key==='w'?-65:65),H*.24,H*.84);e.preventDefault();
    }
  });
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state==='playing')pause();});
  window.addEventListener('resize',resize);
  if(window.visualViewport)window.visualViewport.addEventListener('resize',resize);
  // Generic scaling and UI, no external framework or backend required.
  function spawnObjective(){
    const type=hasGift?'portal':'gift';
    const min=H*.29,max=H*.78;
    const y=rnd(min,max);
    entities.push({type,x:W+78,y,r:type==='portal'?49:29,age:0,speed:Math.min(190,118+delivered*13+rnd(0,15)),route:delivered});
    objectiveAt=Infinity;
    if(type==='portal')toast('Найди светящееся окно!');
  }
  function spawnObstacle(){
    entities.push({type:'snowball',x:W+50,y:rnd(H*.29,H*.81),r:27,age:0,speed:155+delivered*8,phase:rnd(0,7)});
    obstacleAt=elapsed+rnd(4.8,6.4);
  }
  function spawnBonus(){
    entities.push({type:'star',x:W+48,y:rnd(H*.30,H*.78),r:23,age:0,speed:126+delivered*10});
    bonusAt=elapsed+rnd(5,7);
  }
  function burst(x,y,n,color){
    for(let i=0;i<n;i++){
      const a=rnd(0,Math.PI*2),v=rnd(36,205);
      effects.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-25,life:rnd(.35,.9),maxLife:1,rad:rnd(1.3,4.1),color});
    }
  }
  function pickup(ent){
    if(ent.type==='gift'){
      hasGift=true;score+=25;objectiveAt=elapsed+.7;toast('🎁 Подарок найден!');
      burst(ent.x,ent.y,20,'#ffc96a'); haptic('medium');playTone(770,.17);
    } else if(ent.type==='portal'){
      if(!hasGift)return;
      hasGift=false;delivered++;score+=120+Math.max(0,Math.ceil((MAX_TIME-elapsed)*.5));
      objectiveAt=elapsed+1.1;toast(delivered===GOAL?'✨ Все подарки доставлены!':`✉ Доставлено: ${delivered}/${GOAL}`);
      burst(ent.x,ent.y,32,routes[Math.min(delivered-1,4)].color);notification('success');chime();
      if(delivered>=GOAL){score+=Math.ceil(Math.max(0,MAX_TIME-elapsed)*3); updateHud();finish(true);}
    } else if(ent.type==='snowball'){
      if(invuln>0)return;
      health=Math.max(0,health-1); invuln=1.6;shake=9;
      toast('❄ Осторожно, снежок!');burst(ent.x,ent.y,14,'#d9eeff');
      haptic('heavy');playTone(240,.22,'triangle');if(health<=0)finish(false);
    } else if(ent.type==='star'){
      score+=35;burst(ent.x,ent.y,14,'#ffda76');playTone(1150,.1);haptic('light');
    }
    updateHud();
  }
  function update(dt){
    worldOffset+=dt*22;
    for(const p of snow){p.x+=p.drift*dt;p.y+=p.s*dt;if(p.y>H+5){p.y=-8;p.x=rnd(0,W);}if(p.x>W+5)p.x=-5;if(p.x< -5)p.x=W+5;}
    if(state!=='playing')return;
    elapsed+=dt;
    owl.y+=(owl.targetY-owl.y)*Math.min(1,dt*7);
    invuln=Math.max(0,invuln-dt);shake=Math.max(0,shake-dt*25);
    if(elapsed>=MAX_TIME){finish(false);return;}
    if(elapsed>=objectiveAt&&!entities.some(e=>e.type==='gift'||e.type==='portal'))spawnObjective();
    if(elapsed>=obstacleAt)spawnObstacle();
    if(elapsed>=bonusAt)spawnBonus();
    for(const e of entities){
      e.age+=dt;e.x-=e.speed*dt;
      if(e.type==='snowball')e.y+=Math.sin(e.age*3+e.phase)*dt*7;
      if(e.used)continue;
      const dx=Math.abs(e.x-owl.x),dy=Math.abs(e.y-owl.y);
      const tolX=e.type==='portal'?38:e.type==='snowball'?30:31;
      const tolY=e.type==='portal'?58:e.type==='snowball'?32:37;
      if(dx<tolX&&dy<tolY){
        if(e.type==='portal'&&!hasGift)continue;
        if(e.type==='snowball'&&invuln>0)continue;
        e.used=true;pickup(e);
      }
    }
    entities=entities.filter(e=>{
      if(e.used)return false;
      if(e.x< -85){if(e.type==='gift'||e.type==='portal')objectiveAt=elapsed+0.8;return false;}
      return true;
    });
    for(const p of effects){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=105*dt;p.life-=dt;}
    effects=effects.filter(p=>p.life>0);
    updateHud();
  }
  function roundRect(x,y,w,h,r,fill,stroke,line=1){
    ctx.beginPath();ctx.roundRect(x,y,w,h,r);
    if(fill){ctx.fillStyle=fill;ctx.fill();}
    if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=line;ctx.stroke();}
  }
  function glowCircle(x,y,r,color,alpha=.3){
    const g=ctx.createRadialGradient(x,y,2,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'transparent');
    ctx.save();ctx.globalAlpha=alpha;ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);ctx.restore();
  }
  function starPath(x,y,outer=15,inner=6,n=5){ctx.beginPath();for(let i=0;i<n*2;i++){const a=-Math.PI/2+i*Math.PI/n,r=i%2?inner:outer;const px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();}
  function drawSky(){
    // Distant moving spires provide a subtle sense of travel, with the chosen background still visible.
    ctx.save();ctx.globalAlpha=.21;
    for(let i=-1;i<6;i++){
      const baseX=i*143-((worldOffset*.48)%143);
      const top=H*.44+Math.sin(i*3)*37;
      ctx.fillStyle='#071021';ctx.fillRect(baseX,top,37,H-top);
      ctx.beginPath();ctx.moveTo(baseX-7,top);ctx.lineTo(baseX+18,top-84);ctx.lineTo(baseX+45,top);ctx.closePath();ctx.fill();
      ctx.fillStyle='#f2b95f';ctx.globalAlpha=.28;
      for(let j=0;j<2;j++) roundRect(baseX+12,top+36+j*55,12,25,[7,7,0,0],'#f2b95f');
      ctx.globalAlpha=.21;
    }
    ctx.restore();
    for(const f of fireflies){
      const t=worldOffset*.06+f.phase;ctx.globalAlpha=.17+Math.sin(t*3)*.12;
      glowCircle(f.x,f.y,15,'#ffe7a0',.26);
      ctx.fillStyle='#ffe5aa';ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,Math.PI*2);ctx.fill();
    }
    ctx.globalAlpha=1;
  }
  function drawSnow(){ctx.save();ctx.fillStyle='#effaff';for(const p of snow){ctx.globalAlpha=p.a;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();}ctx.restore();}
  function drawGift(x,y,t){
    ctx.save();ctx.translate(x,y+Math.sin(t*4)*3);ctx.rotate(Math.sin(t*2)*.08);
    glowCircle(0,0,56,'#ffc77a',.30);
    ctx.shadowColor='#f5ad66';ctx.shadowBlur=12;
    roundRect(-23,-21,46,43,6,'#b42e43','#ffce77',3);ctx.shadowBlur=0;
    ctx.fillStyle='#ffd371';ctx.fillRect(-5,-21,10,43);ctx.fillRect(-23,-5,46,10);
    ctx.strokeStyle='#ffe9a4';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,-20);ctx.bezierCurveTo(-24,-42,-28,-20,0,-20);ctx.moveTo(0,-20);ctx.bezierCurveTo(21,-42,28,-18,0,-20);ctx.stroke();
    ctx.fillStyle='#fff6c4';ctx.beginPath();ctx.arc(-14,-13,3.2,0,7);ctx.fill();ctx.restore();
  }
  function drawPortal(x,y,t,route){
    const color=routes[Math.min(route,4)].color;
    ctx.save();ctx.translate(x,y);const bob=Math.sin(t*3)*1.5;
    ctx.translate(0,bob);
    glowCircle(0,0,88,color,.31);
    ctx.shadowColor='#000';ctx.shadowBlur=12;
    roundRect(-37,-61,74,124,9,'#2b314b','#c7b18b',3);ctx.shadowBlur=0;
    // Stone details.
    ctx.strokeStyle='#66708c';ctx.lineWidth=1.5;
    for(let yy=-46;yy<61;yy+=22){ctx.beginPath();ctx.moveTo(-35,yy);ctx.lineTo(35,yy);ctx.stroke();}
    ctx.strokeStyle='#f2d59c';ctx.lineWidth=2.5;
    ctx.beginPath();ctx.moveTo(-41,-60);ctx.lineTo(0,-94);ctx.lineTo(41,-60);ctx.closePath();ctx.fillStyle='#383248';ctx.fill();ctx.stroke();
    // Luminous arched window.
    ctx.beginPath();ctx.moveTo(-24,37);ctx.lineTo(-24,-16);ctx.quadraticCurveTo(-24,-49,0,-49);ctx.quadraticCurveTo(24,-49,24,-16);ctx.lineTo(24,37);ctx.closePath();
    const g=ctx.createLinearGradient(0,-49,0,37);g.addColorStop(0,'#fff3b5');g.addColorStop(.55,color);g.addColorStop(1,'#604b6d');
    ctx.fillStyle=g;ctx.shadowColor=color;ctx.shadowBlur=19;ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#ffe8ad';ctx.lineWidth=3;ctx.stroke();
    ctx.strokeStyle='#ffeac1';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,-46);ctx.lineTo(0,37);ctx.moveTo(-23,-1);ctx.lineTo(23,-1);ctx.stroke();
    ctx.fillStyle='#3a2435';ctx.beginPath();ctx.arc(0,20,13,0,7);ctx.fill();ctx.fillStyle='#ffe5a4';ctx.font='bold 18px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(routes[Math.min(route,4)].icon,0,19);
    ctx.restore();
  }
  function drawSnowball(x,y,t){
    ctx.save();ctx.translate(x,y);ctx.rotate(t*1.5);glowCircle(0,0,47,'#c3f4ff',.24);
    ctx.shadowColor='#c1eaff';ctx.shadowBlur=13;
    ctx.beginPath();ctx.arc(0,0,23,0,Math.PI*2);const g=ctx.createRadialGradient(-10,-11,1,0,0,25);g.addColorStop(0,'#fff');g.addColorStop(.67,'#c9e8fb');g.addColorStop(1,'#70a2ce');ctx.fillStyle=g;ctx.fill();ctx.shadowBlur=0;
    ctx.fillStyle='#90bed8';for(let i=0;i<5;i++){const a=i*1.256;ctx.beginPath();ctx.arc(Math.cos(a)*13,Math.sin(a)*13,2.6,0,7);ctx.fill();}
    ctx.strokeStyle='#f8ffff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-7,-14);ctx.lineTo(-2,-10);ctx.stroke();ctx.restore();
  }
  function drawStar(x,y,t){ctx.save();ctx.translate(x,y);ctx.rotate(t*1.5);glowCircle(0,0,48,'#ffe49f',.36);ctx.shadowColor='#ffe3a1';ctx.shadowBlur=13;starPath(0,0,19,8,5);ctx.fillStyle='#ffcf67';ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#fff8cc';ctx.lineWidth=2;ctx.stroke();ctx.restore();}
  function drawOwl(t){
    const width=Math.min(W*.42,190),h=width*442/753;
    ctx.save();ctx.translate(owl.x,owl.y+Math.sin(t*8)*2.8);
    ctx.rotate(Math.sin(t*7)*.035);
    if(invuln>0&&Math.sin(t*27)>0)ctx.globalAlpha=.45;
    glowCircle(-15,6,width*.65,'#ffd9a0',.19);
    if(owlImg.complete&&owlImg.naturalWidth){ctx.drawImage(owlImg,-width*.52,-h*.54,width,h);}
    else{ctx.fillStyle='#fff4dc';ctx.beginPath();ctx.arc(0,0,35,0,7);ctx.fill();ctx.font='45px Arial';ctx.textAlign='center';ctx.fillText('🦉',0,12);}
    if(hasGift){
      ctx.save();ctx.translate(21,h*.35+8);ctx.rotate(.1);
      ctx.shadowColor='#ffd45e';ctx.shadowBlur=13;
      roundRect(-10,-10,20,20,3,'#d7414e','#ffd887',1.5);ctx.shadowBlur=0;ctx.fillStyle='#fddb6b';ctx.fillRect(-2.5,-10,5,20);ctx.fillRect(-10,-2.5,20,5);
      ctx.restore();
    }
    ctx.restore();
  }
  function drawEffects(){ctx.save();for(const p of effects){ctx.globalAlpha=clamp(p.life/.8,0,1);ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=7;ctx.beginPath();ctx.arc(p.x,p.y,p.rad,0,7);ctx.fill();}ctx.restore();}
  function draw(t){
    ctx.clearRect(0,0,W,H);
    ctx.save();if(shake>0)ctx.translate(rnd(-shake,shake),rnd(-shake,shake));
    drawSky();
    for(const ent of entities){switch(ent.type){case 'gift':drawGift(ent.x,ent.y,t);break;case 'portal':drawPortal(ent.x,ent.y,t,ent.route);break;case 'snowball':drawSnowball(ent.x,ent.y,t);break;case 'star':drawStar(ent.x,ent.y,t);break;}}
    if(state!=='menu')drawOwl(t);
    drawEffects();drawSnow();ctx.restore();
  }
  function loop(now){
    if(!lastTime)lastTime=now;
    const dt=Math.min(.045,(now-lastTime)/1000);lastTime=now;
    update(dt);draw(now/1000);requestAnimationFrame(loop);
  }
  resize();showPanel('start');requestAnimationFrame(loop);
})();
