/* Minimal circle physics fallback for offline play when Matter.js CDN is unavailable.
   The full Matter.js engine is preferred whenever it loads successfully. */
(function (global) {
  if (global.Matter) return;
  const TAU = 2 * Math.PI;
  let id = 0;
  function circle(x,y,r,opts={}) {
    return {id:++id,label:opts.label||'circle',shape:'circle',position:{x,y},velocity:{x:0,y:0},
      angle:0, angularVelocity:0,r, restitution:opts.restitution??.1, friction:opts.friction??.25,
      frictionAir:opts.frictionAir??.002, density:opts.density||.001,
      mass: Math.PI*r*r*(opts.density||.001),isStatic:false};
  }
  function rectangle(x,y,w,h,opts={}) {
    return {id:++id,label:'rectangle',shape:'rect',position:{x,y},velocity:{x:0,y:0},
      w,h,isStatic:!!opts.isStatic,restitution:0,angle:0};
  }
  const World = {
    add(world, input) {const arr=Array.isArray(input)?input:[input];for(const b of arr)if(!world.bodies.includes(b))world.bodies.push(b);},
    remove(world, input) {const arr=Array.isArray(input)?input:[input];world.bodies=world.bodies.filter(b=>!arr.includes(b));}
  };
  function solveRect(b,w) {
    const x=Math.max(w.position.x-w.w/2,Math.min(b.position.x,w.position.x+w.w/2));
    const y=Math.max(w.position.y-w.h/2,Math.min(b.position.y,w.position.y+w.h/2));
    let dx=b.position.x-x, dy=b.position.y-y, dd=Math.hypot(dx,dy);
    if(dd>=b.r)return false;
    if(dd<.00001){const dl=Math.abs(b.position.x-(w.position.x-w.w/2)),dr=Math.abs((w.position.x+w.w/2)-b.position.x);
      const dt=Math.abs(b.position.y-(w.position.y-w.h/2)),db=Math.abs((w.position.y+w.h/2)-b.position.y);
      const m=Math.min(dl,dr,dt,db);
      dx=m===dl?-1:m===dr?1:0;dy=m===dt?-1:m===db?1:0;dd=1;
    }
    const nx=dx/dd,ny=dy/dd;const penetration=b.r-(Math.hypot(b.position.x-x,b.position.y-y));
    b.position.x+=nx*(Math.max(0,penetration)+.02);
    b.position.y+=ny*(Math.max(0,penetration)+.02);
    const vn=b.velocity.x*nx+b.velocity.y*ny;
    if(vn<0){b.velocity.x-=(1+b.restitution)*vn*nx;b.velocity.y-=(1+b.restitution)*vn*ny;}
    if(Math.abs(ny)>.5){b.velocity.x*=.97;b.angularVelocity+=(b.velocity.x/b.r)*.005;}
    return true;
  }
  function resolve(a,b) {
    const dx=b.position.x-a.position.x,dy=b.position.y-a.position.y;
    const rad=a.r+b.r, ds=dx*dx+dy*dy;
    if(ds>=rad*rad)return false;
    const d=Math.sqrt(ds)||.0001,nx=dx/d,ny=dy/d,overlap=rad-d;
    const invA=1/a.mass,invB=1/b.mass, inv=invA+invB;
    a.position.x-=nx*overlap*invA/inv*.82;a.position.y-=ny*overlap*invA/inv*.82;
    b.position.x+=nx*overlap*invB/inv*.82;b.position.y+=ny*overlap*invB/inv*.82;
    const vx=b.velocity.x-a.velocity.x,vy=b.velocity.y-a.velocity.y, vn=vx*nx+vy*ny;
    if(vn<0){const impulse=-(1+Math.min(a.restitution,b.restitution))*vn/inv;
      a.velocity.x-=impulse*invA*nx;a.velocity.y-=impulse*invA*ny;
      b.velocity.x+=impulse*invB*nx;b.velocity.y+=impulse*invB*ny;
    }
    return true;
  }
  const Engine = {
    create(){return {world:{bodies:[]},gravity:{x:0,y:1},positionIterations:6,handlers:{}};},
    update(engine,delta=1000/60){
      const step=Math.min(2,delta/(1000/60)),list=engine.world.bodies;
      const circles=list.filter(b=>b.shape==='circle'&&!b.gone);
      const rects=list.filter(b=>b.shape==='rect'&&b.isStatic);
      for(const b of circles){b.velocity.x+=(engine.gravity.x||0)*.27*step;
        b.velocity.y+=(engine.gravity.y||0)*.27*step;
        const friction=Math.pow(1-b.frictionAir,step);
        b.velocity.x*=friction;b.velocity.y*=friction;
        b.position.x+=b.velocity.x*step;b.position.y+=b.velocity.y*step;
        b.angle+=b.angularVelocity*step;b.angularVelocity*=.98;
      }
      let collisions=[];
      for(let it=0;it<Math.min(8,engine.positionIterations||6);it++){
        for(const b of circles)for(const w of rects){if(solveRect(b,w)&&it===0)collisions.push({bodyA:b,bodyB:w});}
        for(let i=0;i<circles.length;i++)for(let j=i+1;j<circles.length;j++){
          const a=circles[i],b=circles[j];if(a.gone||b.gone)continue;
          if(resolve(a,b)&&it===0)collisions.push({bodyA:a,bodyB:b});
        }
      }
      if(collisions.length)for(const cb of (engine.handlers.collisionStart||[]))cb({pairs:collisions});
    }
  };
  const Events={on(engine,event,cb){(engine.handlers[event]||=[]).push(cb);}};
  const Body={setAngle(body,angle){body.angle=angle;}};
  global.Matter={Engine,World,Bodies:{circle,rectangle},Body,Events};
  global.__matterFallback=true;
})(window);
